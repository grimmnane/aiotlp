// 接口
// const host = 'http://10.10.10.152:1001/';
const host = 'http://10.10.10.152:1001';

let token = '';
// 用户信息
const userInfo = {
    // "userNickName": "test",
    // "userAvatarUrl": "https://img.yzcdn.cn/vant/cat.jpeg",
    // "userGender": "0",
    // "phoneNumber": "12345678910",
    // "userAdress": ""
};


//
module.exports = {
    host: host,
    token
}